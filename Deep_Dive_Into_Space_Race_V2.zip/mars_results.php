﻿<!DOCTYPE html>
<html lang="en" class="no-js" >
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DEEP DIVE INTO SPACE RACE V2.0.0 | Space missions module - Mars images module - Daily Temperature of Major Cities - Star Type Classification</title>

    <script>
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- favicons
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

</head>

<body id="top">


    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader"></div>
    </div>


    <!-- page wrap
    ================================================== -->
    <div class="s-pagewrap">


        <!-- # header
        ================================================== -->
        <header class="s-header">
            <div class="row s-header__content">

                <div class="s-header__logo">
                    <a class="logo" href="index-static.html">
                        <img src="images/logo.png" alt="Homepage">
                    </a>
                </div>
    
                <ul class="s-header__social">

                    <li>
                        <a href="https://twitter.com/CelesTrak">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:"><path d="M19.633,7.997c0.013,0.175,0.013,0.349,0.013,0.523c0,5.325-4.053,11.461-11.46,11.461c-2.282,0-4.402-0.661-6.186-1.809 c0.324,0.037,0.636,0.05,0.973,0.05c1.883,0,3.616-0.636,5.001-1.721c-1.771-0.037-3.255-1.197-3.767-2.793 c0.249,0.037,0.499,0.062,0.761,0.062c0.361,0,0.724-0.05,1.061-0.137c-1.847-0.374-3.23-1.995-3.23-3.953v-0.05 c0.537,0.299,1.16,0.486,1.82,0.511C3.534,9.419,2.823,8.184,2.823,6.787c0-0.748,0.199-1.434,0.548-2.032 c1.983,2.443,4.964,4.04,8.306,4.215c-0.062-0.3-0.1-0.611-0.1-0.923c0-2.22,1.796-4.028,4.028-4.028 c1.16,0,2.207,0.486,2.943,1.272c0.91-0.175,1.782-0.512,2.556-0.973c-0.299,0.935-0.936,1.721-1.771,2.22 c0.811-0.088,1.597-0.312,2.319-0.624C21.104,6.712,20.419,7.423,19.633,7.997z"></path></svg>
                            <span class="screen-reader-text">Twitter</span>
                        </a>
                    </li>
                </ul>

            </div> <!-- end s-header__content -->
        </header> <!-- end s-header -->


        <!-- # intro 
        ================================================== -->
		<?php 
			// include the config file to connect to the server and database
			include 'php/db_config.php'; 
			// get the data entered by users from the html form
			$date = $_GET['date'];
			$filter = $_GET['filter'];
			$instrument = $_GET['instrument'];
			$model = $_GET['model'];
			
			// write my query to get the data from mars table
			$mars = $conn->query("SELECT * FROM mars WHERE date LIKE '%{$date}%' AND filter LIKE '%{$filter}%' AND instrument LIKE '%{$instrument}%' AND model LIKE '%{$model}%'");			
			$r = $mars->fetch_object();
		?>
		<section id="intro" class="s-intro">

            <div class="s-intro__bg"></div>

            <div class="row s-intro__content">
                <div class="column lg-12">
                        <div>
                            <span class="results">Below, you will find <br>images from Mars <br>based on your search</span><br>
                            <span class="results">...</span>
                        </div>
                    </div>  <!-- end counter -->

                    <div class="s-intro__content-bottom column lg-12">
                        <h1 class="s-intro__content-title">Images From Mars.</h1>
							<ul>
								<li><?php echo $date; ?></li>
								<li><?php echo $filter; ?></li>
								<li><?php echo $instrument; ?></li>
								<li><?php echo $model; ?></li>
							</ul>					                        
	                    </div>

                </div>

                <div class="s-intro__scroll">
                    <p class="scroll-text">Scroll For More</p>
                    <a href="#info" class="smoothscroll">
                        <div class="mouse"></div>
                    </a>
                    <div class="end-top"></div>
                </div> <!-- end s-intro__scroll -->

            </div> <!-- intro__content -->
        </section> <!-- end s-intro -->


        <!-- # info
        ================================================== -->
        
		<section id="info" class="s-info">

            <div class="s-info__bg"></div>

            <div class="row">
                <div class="column lg-12">
				<form style="text-align:center;" action="index.html">
				<input type="submit" value="Go Back">
				</form>
			<?php
			if($mars->num_rows) {
            while($r = $mars->fetch_object()) {
            ?>        
			 <div class="lg-12 missionresults">
             <div style="padding:20px 10px 0px 10px; text-align:center;" class="item-title"><a target="_blank" href="<?php echo $r->image; ?>"><img style="width:150px; height:150px;" src="<?php echo $r->image; ?>"></a></div>
             <p style="padding:5px 10px 20px 10px;">
		     This photo was taken on <?php echo $r->caption; ?>, 
		     </p>
             </div>
			<?php

						}
					}
				
			?>

					
                </div> <!-- end column -->
            </div> <!-- end row -->

        </section> <!-- end s-info -->


        <!-- # footer
        ================================================== -->
        <footer class="s-footer">

            <div class="row s-footer__top">

                <div class="column lg-6 stack-on-700 s-footer__block s-footer__info">

                    <h4 class="h6">DDS Project</h4>
                    
                    <p class="desc">This application is designed to give everyone an opportunity to go deep into space and get a lot of accurate information from a trusted source.</p>

                    <ul class="s-footer__social">
                        <li>
                            <a href="https://twitter.com/CelesTrak">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:"><path d="M19.633,7.997c0.013,0.175,0.013,0.349,0.013,0.523c0,5.325-4.053,11.461-11.46,11.461c-2.282,0-4.402-0.661-6.186-1.809 c0.324,0.037,0.636,0.05,0.973,0.05c1.883,0,3.616-0.636,5.001-1.721c-1.771-0.037-3.255-1.197-3.767-2.793 c0.249,0.037,0.499,0.062,0.761,0.062c0.361,0,0.724-0.05,1.061-0.137c-1.847-0.374-3.23-1.995-3.23-3.953v-0.05 c0.537,0.299,1.16,0.486,1.82,0.511C3.534,9.419,2.823,8.184,2.823,6.787c0-0.748,0.199-1.434,0.548-2.032 c1.983,2.443,4.964,4.04,8.306,4.215c-0.062-0.3-0.1-0.611-0.1-0.923c0-2.22,1.796-4.028,4.028-4.028 c1.16,0,2.207,0.486,2.943,1.272c0.91-0.175,1.782-0.512,2.556-0.973c-0.299,0.935-0.936,1.721-1.771,2.22 c0.811-0.088,1.597-0.312,2.319-0.624C21.104,6.712,20.419,7.423,19.633,7.997z"></path></svg>
                                <span class="screen-reader-text">Twitter</span>
                            </a>
                        </li>
                    </ul>

                </div> <!-- end s-footer__info -->

                <div class="column lg-6 stack-on-700 s-footer__block s-footer__contact">

                    <h4 class="h6">Contact Info</h4>

                    <div class="row">
                        <div class="column lg-6 stack-on-1000">
                            <div>
                            <strong>Owner</strong> <br>
                            <p>Dr. T.S. Kelso [TS.Kelso@celestrak.org]</p>
                            </div>
                        </div>
                        <div class="column lg-6 stack-on-1000">
                            <div>
                            <strong>Email</strong> <br>
                            <a href="TS.Kelso@celestrak.org">TS.Kelso@celestrak.org</a>
                            </div>
                        </div>
                    </div>
                </div> <!-- end s-footer__contact -->

            </div> <!-- end s-footer__top -->

            <div class="row s-footer__bottom">
                <div class="column lg-12">
                    <div class="ss-copyright">
                        <span>Â© Copyright celestrak 2023</span> 
                        <span>Design & Developed by <a href="#">Majdi Awad</a></span>
                    </div>
                </div>

                <div class="ss-go-top">
                    <a class="smoothscroll" title="Back to Top" href="#top">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill:rgba(0, 0, 0, 1);transform:;-ms-filter:"><path d="M6 4H18V6H6zM11 14L11 20 13 20 13 14 18 14 12 8 6 14z"></path></svg>
                     </a>
                </div>
            </div> <!--end s-footer__bottom -->

        </footer> <!--end s-footer -->



    <!-- Java Script
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>